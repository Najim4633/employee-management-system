package com.project.empcrud.entity;

import org.hibernate.annotations.GenericGenerator;

import com.project.empcrud.entity.config.EmpIdGenrator;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(generator = "id")
	@GenericGenerator(name = "id",type = EmpIdGenrator.class)
	String id;
	String name;
	double salary;
	String designation;
	String address;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
}
