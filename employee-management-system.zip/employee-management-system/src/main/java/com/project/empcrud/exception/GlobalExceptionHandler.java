package com.project.empcrud.exception;

public class GlobalExceptionHandler {

}
